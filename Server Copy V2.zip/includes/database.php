<?php

$host = "localhost"; 
$user = "mjonline_free";
$pass = "mjonline_free";
$name = "mjonline_free";