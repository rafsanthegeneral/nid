<?php

$host = "localhost"; 
$user = "root";
$pass = "";
$name = "nid";